#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

import java.util.Scanner;

public class ${NAME} {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

    }
}
